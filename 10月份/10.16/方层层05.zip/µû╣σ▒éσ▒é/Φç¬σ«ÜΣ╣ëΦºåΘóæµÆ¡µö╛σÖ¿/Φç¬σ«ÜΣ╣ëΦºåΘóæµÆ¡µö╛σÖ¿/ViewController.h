//
//  ViewController.h
//  自定义视频播放器
//
//  Created by codygao on 16/10/16.
//  Copyright © 2016年 HM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

